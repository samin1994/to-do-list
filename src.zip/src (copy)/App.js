import React from 'react';
import logo from './logo.svg';
import './App.css';
import Main from './MainComponent';


function App() {
  return (
    <>
      <Main />
    </>
  );
}

export default App;
